/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/boot/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/boot/app-params.js":
/*!********************************!*\
  !*** ./src/boot/app-params.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../platform */ "./src/platform/index.js");
/**
 * @author al88
 * @overview Модуль для работы с параметрами запуска приложения
 */

/* harmony default export */ __webpack_exports__["default"] = ({
  /**
   * Сохраняем параметры запуска в глобальную переменную `launchParams`
   */
  init: function init() {
    window.launchParams = _platform__WEBPACK_IMPORTED_MODULE_0__["default"].getLaunchParams();
  },

  get isEmpty() {
    return Boolean(launchParams);
  },

  get: function get(key) {
    return this._isLaunchParamExist(key) ? window.launchParams[key] : appConfig[key];
  },
  _isLaunchParamExist: function _isLaunchParamExist(key) {
    return window.launchParams && window.launchParams[key] !== undefined;
  }
});

/***/ }),

/***/ "./src/boot/app.js":
/*!*************************!*\
  !*** ./src/boot/app.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return BootApp; });
/* harmony import */ var _platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../platform */ "./src/platform/index.js");
/* harmony import */ var _app_params__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-params */ "./src/boot/app-params.js");
/* harmony import */ var _logo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./logo */ "./src/boot/logo.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils */ "./src/utils/index.js");
/* harmony import */ var _statistics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./statistics */ "./src/boot/statistics.js");
function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

/**
 * Boot app.
 */

/**
 * Параметры приложения.
 * Если приложение было открыто с передачей параметров для отладки,
 * то из объекта RequestedAppControl вытаскиваем адреса стилей, js-скрипта и открываемой в дальнейшем WebView.
 * Если же приложение было открыто стандартно - из ярлыка в SmartHub'е,
 * то загружаются ресурсы по prod-ссылкам.
 */

/* global appConfig */






var BootApp =
/*#__PURE__*/
function () {
  function BootApp() {
    _classCallCheck(this, BootApp);
  }

  _createClass(BootApp, [{
    key: "run",
    value: function run() {
      var _this = this;

      Promise.resolve().then(function () {
        return _platform__WEBPACK_IMPORTED_MODULE_0__["default"].setup();
      }).then(function () {
        return _app_params__WEBPACK_IMPORTED_MODULE_1__["default"].init();
      }).then(function () {
        return _this._boot();
      })["catch"](function (e) {
        return logger.logError("Error: ".concat(e));
      });
    }
  }, {
    key: "_boot",
    value: function _boot() {
      Promise.resolve().then(showDeviceInfo).then(showAppInfo).then(function () {
        return _logo__WEBPACK_IMPORTED_MODULE_2__["show"]();
      }).then(setupLogger).then(loadJS).then(function () {
        return _statistics__WEBPACK_IMPORTED_MODULE_4__["sendEnvInfo"]();
      })["catch"](function (e) {
        return logger.logError("Error: ".concat(e));
      });
    }
  }]);

  return BootApp;
}();



function showDeviceInfo() {
  logger.log("Screen: ".concat(screen.width, "x").concat(screen.height));
}

function showAppInfo() {
  return _platform__WEBPACK_IMPORTED_MODULE_0__["default"].getAppInfo().then(function (_ref) {
    var version = _ref.version;
    return logAppInfo(version);
  });
}

function logAppInfo(version) {
  var buildDate = _utils__WEBPACK_IMPORTED_MODULE_3__["prettyDate"](new Date(appConfig.buildDate));
  logger.log("Version: ".concat(version, " (").concat(appConfig.buildType, "), buildDate: ").concat(buildDate));
  logger.log("Launch params: ".concat(_app_params__WEBPACK_IMPORTED_MODULE_1__["default"].isEmpty ? 'yes' : 'no'));
}

function setupLogger() {
  if (_app_params__WEBPACK_IMPORTED_MODULE_1__["default"].get('showLog')) {
    logger.show();
  }
}

function loadJS() {
  var jsLink = getJSLink();
  logger.log("Loading js: ".concat(jsLink)); // todo Исправить черный экран в случае, если скрипт не загрузился

  timings.start('loaderLoad');
  return Promise.resolve().then(function () {
    return _utils__WEBPACK_IMPORTED_MODULE_3__["appendJSScript"](jsLink);
  }).then(function () {
    return timings.finish('loaderLoad');
  })["catch"](function (e) {
    return logger.logError("Error: ".concat(e));
  });
}

function getJSLink() {
  var jsParam = _app_params__WEBPACK_IMPORTED_MODULE_1__["default"].get('js');
  return _app_params__WEBPACK_IMPORTED_MODULE_1__["default"].get('debug') ? _utils__WEBPACK_IMPORTED_MODULE_3__["convertToDebugUrl"](jsParam) : jsParam;
}

/***/ }),

/***/ "./src/boot/index.css":
/*!****************************!*\
  !*** ./src/boot/index.css ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "./src/boot/index.js":
/*!***************************!*\
  !*** ./src/boot/index.js ***!
  \***************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.css */ "./src/boot/index.css");
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_index_css__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _app__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app */ "./src/boot/app.js");
/**
 * @author al88
 * @overview Входная точка скрипта ТВ-приложения
 */


window.addEventListener('DOMContentLoaded', function () {
  return new _app__WEBPACK_IMPORTED_MODULE_1__["default"]().run();
});
timings.finish('localResourcesLoad');

/***/ }),

/***/ "./src/boot/logo.js":
/*!**************************!*\
  !*** ./src/boot/logo.js ***!
  \**************************/
/*! exports provided: show */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "show", function() { return show; });
function show() {
  var el = document.createElement('div');
  el.id = 'logo';
  document.body.appendChild(el);
  setTimeout(function () {
    return el.style.opacity = 1;
  }, 0);
}

/***/ }),

/***/ "./src/boot/statistics.js":
/*!********************************!*\
  !*** ./src/boot/statistics.js ***!
  \********************************/
/*! exports provided: sendEnvInfo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendEnvInfo", function() { return sendEnvInfo; });
/* harmony import */ var _platform__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../platform */ "./src/platform/index.js");
/**
 * Модуль для подготовки и отправки статистики
 */

function sendEnvInfo() {
  var tasks = [getAppInfo(), getNetworkInfo(), getDeviceInfo()];
  Promise.all(tasks).then(function (infos) {
    return infos.reduce(function (result, info) {
      return Object.assign(result, info);
    }, {});
  }).then(function (params) {
    return metrika.sendParams(params);
  })["catch"](function (e) {
    return logger.logError("Error: ".concat(e));
  });
}

function getAppInfo() {
  return _platform__WEBPACK_IMPORTED_MODULE_0__["default"].getAppInfo().then(function (_ref) {
    var appVersion = _ref.version;
    return {
      appVersion: appVersion
    };
  });
}

function getNetworkInfo() {
  return _platform__WEBPACK_IMPORTED_MODULE_0__["default"].getNetworkInfo().then(function (_ref2) {
    var network = _ref2.type;
    return {
      network: network
    };
  });
}

function getDeviceInfo() {
  return _platform__WEBPACK_IMPORTED_MODULE_0__["default"].getDeviceInfo().then(function (_ref3) {
    var platform = _ref3.platform,
        modelCode = _ref3.modelCode,
        modelYear = _ref3.modelYear,
        modelName = _ref3.modelName,
        firmware = _ref3.firmware,
        osVersion = _ref3.osVersion;
    return {
      platform: platform,
      modelCode: modelCode,
      modelYear: modelYear,
      modelName: modelName,
      firmware: firmware,
      osVersion: osVersion
    };
  });
}

/***/ }),

/***/ "./src/platform/index.js":
/*!*******************************!*\
  !*** ./src/platform/index.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var platformApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! platformApi */ "./src/platform/tizen/index.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/utils/index.js");
/**
 * Общая обертка над API платформ
 */


/* harmony default export */ __webpack_exports__["default"] = ({
  setup: setup,
  getAppInfo: getAppInfo,
  getLaunchParams: getLaunchParams,
  getNetworkInfo: getNetworkInfo,
  getDeviceInfo: getDeviceInfo,
  closeApp: closeApp
});
/**
 * @returns {Promise}
 */

function setup() {
  return Object(_utils__WEBPACK_IMPORTED_MODULE_1__["promisify"])(function () {
    return platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].setup();
  });
}
/**
 * @returns {Promise.<Object>}
 */


function getAppInfo() {
  return Object(_utils__WEBPACK_IMPORTED_MODULE_1__["promisify"])(function () {
    return platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].getAppInfo();
  });
}
/**
 * @returns {Object}
 */


function getLaunchParams() {
  return platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].getLaunchParams();
}
/**
 * @returns {Promise.<Object>}
 */


function getNetworkInfo() {
  return Object(_utils__WEBPACK_IMPORTED_MODULE_1__["promisify"])(function () {
    return platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].getNetworkInfo();
  });
}
/**
 * @returns {Promise.<Object>}
 */


function getDeviceInfo() {
  return Object(_utils__WEBPACK_IMPORTED_MODULE_1__["promisify"])(function () {
    return platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].getDeviceInfo();
  });
}

function closeApp() {
  platformApi__WEBPACK_IMPORTED_MODULE_0__["default"].closeApp();
}

/***/ }),

/***/ "./src/platform/network-types.js":
/*!***************************************!*\
  !*** ./src/platform/network-types.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/**
 * Типы подключения
 */
/* harmony default export */ __webpack_exports__["default"] = ({
  DISCONNECTED: 'DISCONNECTED',
  WIFI: 'WIFI',
  WIRED: 'ETHERNET',
  CELLULAR: 'CELLULAR'
});

/***/ }),

/***/ "./src/platform/tizen/index.js":
/*!*************************************!*\
  !*** ./src/platform/tizen/index.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _network_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../network-types */ "./src/platform/network-types.js");
/* harmony import */ var _launch_params__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./launch-params */ "./src/platform/tizen/launch-params.js");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../utils */ "./src/utils/index.js");
/**
 * Tizen platform implementation. Uses global `tizen` and `webapis`.
 *
 * See: http://developer.samsung.com/tv/develop/api-references
 */



var API_SCRIPT_URL = '$WEBAPIS/webapis/webapis.js';
var DISCONNECTED = _network_types__WEBPACK_IMPORTED_MODULE_0__["default"].DISCONNECTED,
    WIFI = _network_types__WEBPACK_IMPORTED_MODULE_0__["default"].WIFI,
    WIRED = _network_types__WEBPACK_IMPORTED_MODULE_0__["default"].WIRED,
    CELLULAR = _network_types__WEBPACK_IMPORTED_MODULE_0__["default"].CELLULAR;
/* harmony default export */ __webpack_exports__["default"] = ({
  setup: setup,
  getAppInfo: getAppInfo,
  getLaunchParams: _launch_params__WEBPACK_IMPORTED_MODULE_1__["getLaunchParams"],
  getNetworkInfo: getNetworkInfo,
  getDeviceInfo: getDeviceInfo,
  closeApp: closeApp
});

function setup() {
  logger.log("Loading js: ".concat(API_SCRIPT_URL));
  return Object(_utils__WEBPACK_IMPORTED_MODULE_2__["appendJSScript"])(API_SCRIPT_URL);
}

function getAppInfo() {
  var version = tizen.application.getAppInfo().version;
  return {
    version: version
  };
}

function closeApp() {
  tizen.application.getCurrentApplication().exit();
}

function getNetworkInfo() {
  var code = webapis.network.getActiveConnectionType();
  var type = [DISCONNECTED, WIFI, CELLULAR, WIRED][code];
  return {
    type: type
  };
}

function getDeviceInfo() {
  var modelCode = webapis.productinfo.getModelCode();
  var modelYear = modelCode.split('_')[0];
  var modelName = webapis.productinfo.getRealModel();
  var firmware = webapis.productinfo.getFirmware();
  return {
    platform: 'Tizen',
    modelCode: modelCode,
    modelYear: modelYear,
    modelName: modelName,
    firmware: firmware
  };
}

/***/ }),

/***/ "./src/platform/tizen/launch-params.js":
/*!*********************************************!*\
  !*** ./src/platform/tizen/launch-params.js ***!
  \*********************************************/
/*! exports provided: getLaunchParams */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLaunchParams", function() { return getLaunchParams; });
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

/**
 * @author al88
 * @overview Через этот модуль можно получить параметры запуска приложения в распаршенном виде
 * @see https://developer.samsung.com/tv/develop/extension-libraries/smart-view-sdk/sender-apps/android-sender-app/enhanced-features#startargs
 */
var DEFAULT_LAUNCH_OPERATION = 'http://tizen.org/appcontrol/operation/default';
var PARAMS_DATA_KEY = 'PAYLOAD';
/**
 * Вытаскивает адреса загружаемых ресурсов из параметров запуска.
 * Если приложение запущено стандартно - из Smart Hub - то параметров запуска не будет.
 * Тут важно проверять операцию http://tizen.org/appcontrol/operation/default, т.к. при запуске из панели превью
 * в PAYLOAD все-таки будут данные, но операция будет другая. Обработка AppControl для панели превью сделана
 * в server скриптах для возможности легко обновить. А тут оставляем только парсинг параметров запуска,
 * чтобы загрузить нужные скрипты.
 * Из-за того что при дебаге на tizen'ах нет возможности пробросить параметры запуска, делаем также фолбэк на считывание
 * параметров запуска из урла (https://st.yandex-team.ru/SMARTTV-137)
 *
 * @see http://developer.samsung.com/tv/develop/api-references/tizen-web-device-api-references/application-api#ApplicationControl
 *
 * @returns {?Object}
 */

function getLaunchParams() {
  return getTizenLaunchParams() || getUrlLaunchParams();
}

function getTizenLaunchParams() {
  var reqAppControl = tizen.application.getCurrentApplication().getRequestedAppControl();

  if (!isRequestedAppControlValid(reqAppControl)) {
    return null;
  }

  if (reqAppControl.appControl.operation !== DEFAULT_LAUNCH_OPERATION) {
    return null;
  }

  var params = getParams(reqAppControl.appControl);

  if (!params) {
    return null;
  }
  /**
   * В случае обычного запуска нужно дополнительно задекодить строковые параметры,
   * так как они должны были быть заэнкожены на клиенте, запустившем приложение, для того,
   * чтобы не возникала ошибка 500 на телевизоре из-за русских символов
   *
   * @see https://github.yandex-team.ru/desktop/chrome-nano/blob/master/extensions/tv/src/background/vendors/samsung/runner.js#L47
   */


  return parseJsonSafe(params, decodeIfString);
}

function getUrlLaunchParams() {
  var launchParams = {};
  var searchParams = (location.search || '').replace(/^\?/, '').split('&');
  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = searchParams[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var param = _step.value;

      var _param$split = param.split('='),
          _param$split2 = _slicedToArray(_param$split, 2),
          name = _param$split2[0],
          value = _param$split2[1];

      launchParams[name] = decodeURIComponent(value);
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator["return"] != null) {
        _iterator["return"]();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  return Object.keys(launchParams).length > 0 ? launchParams : null;
}

function isRequestedAppControlValid(reqAppControl) {
  return reqAppControl && reqAppControl.appControl && reqAppControl.appControl.operation && reqAppControl.appControl.data && reqAppControl.appControl.data.length;
}

function getParams(appControl) {
  var params = getAppControlDataByKey(appControl.data, PARAMS_DATA_KEY);

  if (!areParamsValid(params)) {
    return null;
  }

  return params.value[0];
}

function areParamsValid(params) {
  return params && params.key && params.value && params.value.length === 1; // Все параметры передаются в одной строке
}
/**
 * Не можем использовать Array.prototype.find(), так как он не поддерживается на ТВ
 * @param {Array} appControlData
 * @param {String} key
 * @returns {Array|null}
 *
 * @see http://developer.samsung.com/tv/develop/api-references/tizen-web-device-api-references/application-api#ApplicationControlData
 */


function getAppControlDataByKey(appControlData, key) {
  for (var i = 0; i < appControlData.length; i++) {
    if (appControlData[i].key === key) {
      return appControlData[i];
    }
  }

  return null;
}

function parseJsonSafe(value, reviver) {
  try {
    return JSON.parse(value, reviver);
  } catch (ex) {
    return null;
  }
}

function decodeIfString(key, value) {
  return typeof value === 'string' ? decodeURIComponent(value) : value;
}

/***/ }),

/***/ "./src/utils/index.js":
/*!****************************!*\
  !*** ./src/utils/index.js ***!
  \****************************/
/*! exports provided: appendJSScript, prettyDate, promisify, convertToDebugUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appendJSScript", function() { return appendJSScript; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "prettyDate", function() { return prettyDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "promisify", function() { return promisify; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "convertToDebugUrl", function() { return convertToDebugUrl; });
/**
 * @author al88
 * @overview Утилитарные функции
 */

/**
 * @param {String} jsSrc
 * @returns {Promise.<Element>}
 */
function appendJSScript(jsSrc) {
  var jsScript = document.createElement('script');
  jsScript.src = jsSrc;
  jsScript.type = 'text/javascript';
  jsScript.setAttribute('crossorigin', 'anonymous');
  document.head.appendChild(jsScript);
  return waitForResourceLoading(jsScript);
}
function prettyDate(date) {
  var day = padLeftZero(date.getDate());
  var month = padLeftZero(date.getMonth() + 1);
  var year = date.getFullYear();
  var hours = padLeftZero(date.getHours());
  var minutes = padLeftZero(date.getMinutes());
  return "".concat(day, ".").concat(month, ".").concat(year, " ").concat(hours, ":").concat(minutes);
}
function promisify(fn) {
  return Promise.resolve().then(function () {
    return fn();
  });
}
function convertToDebugUrl(url) {
  return typeof url === 'string' ? url.replace(/\.js$/i, '.debug.js') : url;
}

function waitForResourceLoading(resource) {
  return new Promise(function (resolve, reject) {
    resource.addEventListener('load', function () {
      return resolve(resource);
    });
    resource.addEventListener('error', function (error) {
      return reject(error, resource);
    });
  });
}

function padLeftZero(str) {
  return "0".concat(str).slice(-2);
}

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL2Jvb3QvYXBwLXBhcmFtcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYm9vdC9hcHAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2Jvb3QvaW5kZXguY3NzP2VhYzgiLCJ3ZWJwYWNrOi8vLy4vc3JjL2Jvb3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2Jvb3QvbG9nby5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvYm9vdC9zdGF0aXN0aWNzLmpzIiwid2VicGFjazovLy8uL3NyYy9wbGF0Zm9ybS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcGxhdGZvcm0vbmV0d29yay10eXBlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvcGxhdGZvcm0vdGl6ZW4vaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BsYXRmb3JtL3RpemVuL2xhdW5jaC1wYXJhbXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3V0aWxzL2luZGV4LmpzIl0sIm5hbWVzIjpbImluaXQiLCJ3aW5kb3ciLCJsYXVuY2hQYXJhbXMiLCJwbGF0Zm9ybSIsImdldExhdW5jaFBhcmFtcyIsImlzRW1wdHkiLCJCb29sZWFuIiwiZ2V0Iiwia2V5IiwiX2lzTGF1bmNoUGFyYW1FeGlzdCIsImFwcENvbmZpZyIsInVuZGVmaW5lZCIsIkJvb3RBcHAiLCJQcm9taXNlIiwicmVzb2x2ZSIsInRoZW4iLCJzZXR1cCIsImFwcFBhcmFtcyIsIl9ib290IiwiZSIsImxvZ2dlciIsImxvZ0Vycm9yIiwic2hvd0RldmljZUluZm8iLCJzaG93QXBwSW5mbyIsImxvZ28iLCJzZXR1cExvZ2dlciIsImxvYWRKUyIsInN0YXRpc3RpY3MiLCJsb2ciLCJzY3JlZW4iLCJ3aWR0aCIsImhlaWdodCIsImdldEFwcEluZm8iLCJ2ZXJzaW9uIiwibG9nQXBwSW5mbyIsImJ1aWxkRGF0ZSIsInV0aWxzIiwiRGF0ZSIsImJ1aWxkVHlwZSIsInNob3ciLCJqc0xpbmsiLCJnZXRKU0xpbmsiLCJ0aW1pbmdzIiwic3RhcnQiLCJmaW5pc2giLCJqc1BhcmFtIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJ1biIsImVsIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50IiwiaWQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJzZXRUaW1lb3V0Iiwic3R5bGUiLCJvcGFjaXR5Iiwic2VuZEVudkluZm8iLCJ0YXNrcyIsImdldE5ldHdvcmtJbmZvIiwiZ2V0RGV2aWNlSW5mbyIsImFsbCIsImluZm9zIiwicmVkdWNlIiwicmVzdWx0IiwiaW5mbyIsIk9iamVjdCIsImFzc2lnbiIsInBhcmFtcyIsIm1ldHJpa2EiLCJzZW5kUGFyYW1zIiwiYXBwVmVyc2lvbiIsIm5ldHdvcmsiLCJ0eXBlIiwibW9kZWxDb2RlIiwibW9kZWxZZWFyIiwibW9kZWxOYW1lIiwiZmlybXdhcmUiLCJvc1ZlcnNpb24iLCJjbG9zZUFwcCIsInByb21pc2lmeSIsInBsYXRmb3JtQXBpIiwiRElTQ09OTkVDVEVEIiwiV0lGSSIsIldJUkVEIiwiQ0VMTFVMQVIiLCJBUElfU0NSSVBUX1VSTCIsIm5ldHdvcmtUeXBlcyIsImFwcGVuZEpTU2NyaXB0IiwidGl6ZW4iLCJhcHBsaWNhdGlvbiIsImdldEN1cnJlbnRBcHBsaWNhdGlvbiIsImV4aXQiLCJjb2RlIiwid2ViYXBpcyIsImdldEFjdGl2ZUNvbm5lY3Rpb25UeXBlIiwicHJvZHVjdGluZm8iLCJnZXRNb2RlbENvZGUiLCJzcGxpdCIsImdldFJlYWxNb2RlbCIsImdldEZpcm13YXJlIiwiREVGQVVMVF9MQVVOQ0hfT1BFUkFUSU9OIiwiUEFSQU1TX0RBVEFfS0VZIiwiZ2V0VGl6ZW5MYXVuY2hQYXJhbXMiLCJnZXRVcmxMYXVuY2hQYXJhbXMiLCJyZXFBcHBDb250cm9sIiwiZ2V0UmVxdWVzdGVkQXBwQ29udHJvbCIsImlzUmVxdWVzdGVkQXBwQ29udHJvbFZhbGlkIiwiYXBwQ29udHJvbCIsIm9wZXJhdGlvbiIsImdldFBhcmFtcyIsInBhcnNlSnNvblNhZmUiLCJkZWNvZGVJZlN0cmluZyIsInNlYXJjaFBhcmFtcyIsImxvY2F0aW9uIiwic2VhcmNoIiwicmVwbGFjZSIsInBhcmFtIiwibmFtZSIsInZhbHVlIiwiZGVjb2RlVVJJQ29tcG9uZW50Iiwia2V5cyIsImxlbmd0aCIsImRhdGEiLCJnZXRBcHBDb250cm9sRGF0YUJ5S2V5IiwiYXJlUGFyYW1zVmFsaWQiLCJhcHBDb250cm9sRGF0YSIsImkiLCJyZXZpdmVyIiwiSlNPTiIsInBhcnNlIiwiZXgiLCJqc1NyYyIsImpzU2NyaXB0Iiwic3JjIiwic2V0QXR0cmlidXRlIiwiaGVhZCIsIndhaXRGb3JSZXNvdXJjZUxvYWRpbmciLCJwcmV0dHlEYXRlIiwiZGF0ZSIsImRheSIsInBhZExlZnRaZXJvIiwiZ2V0RGF0ZSIsIm1vbnRoIiwiZ2V0TW9udGgiLCJ5ZWFyIiwiZ2V0RnVsbFllYXIiLCJob3VycyIsImdldEhvdXJzIiwibWludXRlcyIsImdldE1pbnV0ZXMiLCJmbiIsImNvbnZlcnRUb0RlYnVnVXJsIiwidXJsIiwicmVzb3VyY2UiLCJyZWplY3QiLCJlcnJvciIsInN0ciIsInNsaWNlIl0sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7OztBQUdBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQSxrREFBMEMsZ0NBQWdDO0FBQzFFO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsZ0VBQXdELGtCQUFrQjtBQUMxRTtBQUNBLHlEQUFpRCxjQUFjO0FBQy9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxpREFBeUMsaUNBQWlDO0FBQzFFLHdIQUFnSCxtQkFBbUIsRUFBRTtBQUNySTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBLG1DQUEyQiwwQkFBMEIsRUFBRTtBQUN2RCx5Q0FBaUMsZUFBZTtBQUNoRDtBQUNBO0FBQ0E7O0FBRUE7QUFDQSw4REFBc0QsK0RBQStEOztBQUVySDtBQUNBOzs7QUFHQTtBQUNBOzs7Ozs7Ozs7Ozs7O0FDbEZBO0FBQUE7QUFBQTs7OztBQUtBO0FBRWU7QUFFYjs7O0FBR0FBLE1BTGEsa0JBS047QUFDTEMsVUFBTSxDQUFDQyxZQUFQLEdBQXNCQyxpREFBUSxDQUFDQyxlQUFULEVBQXRCO0FBQ0QsR0FQWTs7QUFTYixNQUFJQyxPQUFKLEdBQWM7QUFDWixXQUFPQyxPQUFPLENBQUNKLFlBQUQsQ0FBZDtBQUNELEdBWFk7O0FBYWJLLEtBYmEsZUFhVEMsR0FiUyxFQWFKO0FBQ1AsV0FBTyxLQUFLQyxtQkFBTCxDQUF5QkQsR0FBekIsSUFBZ0NQLE1BQU0sQ0FBQ0MsWUFBUCxDQUFvQk0sR0FBcEIsQ0FBaEMsR0FBMkRFLFNBQVMsQ0FBQ0YsR0FBRCxDQUEzRTtBQUNELEdBZlk7QUFpQmJDLHFCQWpCYSwrQkFpQk9ELEdBakJQLEVBaUJZO0FBQ3ZCLFdBQU9QLE1BQU0sQ0FBQ0MsWUFBUCxJQUF1QkQsTUFBTSxDQUFDQyxZQUFQLENBQW9CTSxHQUFwQixNQUE2QkcsU0FBM0Q7QUFDRDtBQW5CWSxDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTs7OztBQUlBOzs7Ozs7OztBQVFBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7SUFFcUJDLE87Ozs7Ozs7OzswQkFDYjtBQUFBOztBQUNKQyxhQUFPLENBQUNDLE9BQVIsR0FDR0MsSUFESCxDQUNRO0FBQUEsZUFBTVosaURBQVEsQ0FBQ2EsS0FBVCxFQUFOO0FBQUEsT0FEUixFQUVHRCxJQUZILENBRVE7QUFBQSxlQUFNRSxtREFBUyxDQUFDakIsSUFBVixFQUFOO0FBQUEsT0FGUixFQUdHZSxJQUhILENBR1E7QUFBQSxlQUFNLEtBQUksQ0FBQ0csS0FBTCxFQUFOO0FBQUEsT0FIUixXQUlTLFVBQUFDLENBQUM7QUFBQSxlQUFJQyxNQUFNLENBQUNDLFFBQVAsa0JBQTBCRixDQUExQixFQUFKO0FBQUEsT0FKVjtBQUtEOzs7NEJBRU87QUFDTk4sYUFBTyxDQUFDQyxPQUFSLEdBQ0dDLElBREgsQ0FDUU8sY0FEUixFQUVHUCxJQUZILENBRVFRLFdBRlIsRUFHR1IsSUFISCxDQUdRO0FBQUEsZUFBTVMsMENBQUEsRUFBTjtBQUFBLE9BSFIsRUFJR1QsSUFKSCxDQUlRVSxXQUpSLEVBS0dWLElBTEgsQ0FLUVcsTUFMUixFQU1HWCxJQU5ILENBTVE7QUFBQSxlQUFNWSx1REFBQSxFQUFOO0FBQUEsT0FOUixXQU9TLFVBQUFSLENBQUM7QUFBQSxlQUFJQyxNQUFNLENBQUNDLFFBQVAsa0JBQTBCRixDQUExQixFQUFKO0FBQUEsT0FQVjtBQVFEOzs7Ozs7OztBQUdILFNBQVNHLGNBQVQsR0FBMEI7QUFDeEJGLFFBQU0sQ0FBQ1EsR0FBUCxtQkFBc0JDLE1BQU0sQ0FBQ0MsS0FBN0IsY0FBc0NELE1BQU0sQ0FBQ0UsTUFBN0M7QUFDRDs7QUFFRCxTQUFTUixXQUFULEdBQXVCO0FBQ3JCLFNBQU9wQixpREFBUSxDQUFDNkIsVUFBVCxHQUNKakIsSUFESSxDQUNDO0FBQUEsUUFBR2tCLE9BQUgsUUFBR0EsT0FBSDtBQUFBLFdBQWlCQyxVQUFVLENBQUNELE9BQUQsQ0FBM0I7QUFBQSxHQURELENBQVA7QUFFRDs7QUFFRCxTQUFTQyxVQUFULENBQW9CRCxPQUFwQixFQUE2QjtBQUMzQixNQUFNRSxTQUFTLEdBQUdDLGlEQUFBLENBQWlCLElBQUlDLElBQUosQ0FBUzNCLFNBQVMsQ0FBQ3lCLFNBQW5CLENBQWpCLENBQWxCO0FBQ0FmLFFBQU0sQ0FBQ1EsR0FBUCxvQkFBdUJLLE9BQXZCLGVBQW1DdkIsU0FBUyxDQUFDNEIsU0FBN0MsMkJBQXVFSCxTQUF2RTtBQUNBZixRQUFNLENBQUNRLEdBQVAsMEJBQTZCWCxtREFBUyxDQUFDWixPQUFWLEdBQW9CLEtBQXBCLEdBQTRCLElBQXpEO0FBQ0Q7O0FBRUQsU0FBU29CLFdBQVQsR0FBdUI7QUFDckIsTUFBSVIsbURBQVMsQ0FBQ1YsR0FBVixDQUFjLFNBQWQsQ0FBSixFQUE4QjtBQUM1QmEsVUFBTSxDQUFDbUIsSUFBUDtBQUNEO0FBQ0Y7O0FBRUQsU0FBU2IsTUFBVCxHQUFrQjtBQUNoQixNQUFNYyxNQUFNLEdBQUdDLFNBQVMsRUFBeEI7QUFDQXJCLFFBQU0sQ0FBQ1EsR0FBUCx1QkFBMEJZLE1BQTFCLEdBRmdCLENBR2hCOztBQUNBRSxTQUFPLENBQUNDLEtBQVIsQ0FBYyxZQUFkO0FBQ0EsU0FBTzlCLE9BQU8sQ0FBQ0MsT0FBUixHQUNKQyxJQURJLENBQ0M7QUFBQSxXQUFNcUIscURBQUEsQ0FBcUJJLE1BQXJCLENBQU47QUFBQSxHQURELEVBRUp6QixJQUZJLENBRUM7QUFBQSxXQUFNMkIsT0FBTyxDQUFDRSxNQUFSLENBQWUsWUFBZixDQUFOO0FBQUEsR0FGRCxXQUdFLFVBQUF6QixDQUFDO0FBQUEsV0FBSUMsTUFBTSxDQUFDQyxRQUFQLGtCQUEwQkYsQ0FBMUIsRUFBSjtBQUFBLEdBSEgsQ0FBUDtBQUlEOztBQUVELFNBQVNzQixTQUFULEdBQXFCO0FBQ25CLE1BQU1JLE9BQU8sR0FBRzVCLG1EQUFTLENBQUNWLEdBQVYsQ0FBYyxJQUFkLENBQWhCO0FBQ0EsU0FBT1UsbURBQVMsQ0FBQ1YsR0FBVixDQUFjLE9BQWQsSUFBeUI2Qix3REFBQSxDQUF3QlMsT0FBeEIsQ0FBekIsR0FBNERBLE9BQW5FO0FBQ0QsQzs7Ozs7Ozs7Ozs7QUM1RUQsdUM7Ozs7Ozs7Ozs7OztBQ0FBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7QUFLQTtBQUNBO0FBRUE1QyxNQUFNLENBQUM2QyxnQkFBUCxDQUF3QixrQkFBeEIsRUFBNEM7QUFBQSxTQUFNLElBQUlsQyw0Q0FBSixHQUFjbUMsR0FBZCxFQUFOO0FBQUEsQ0FBNUM7QUFFQUwsT0FBTyxDQUFDRSxNQUFSLENBQWUsb0JBQWYsRTs7Ozs7Ozs7Ozs7O0FDVkE7QUFBQTtBQUFPLFNBQVNMLElBQVQsR0FBZ0I7QUFDckIsTUFBTVMsRUFBRSxHQUFHQyxRQUFRLENBQUNDLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBWDtBQUNBRixJQUFFLENBQUNHLEVBQUgsR0FBUSxNQUFSO0FBQ0FGLFVBQVEsQ0FBQ0csSUFBVCxDQUFjQyxXQUFkLENBQTBCTCxFQUExQjtBQUNBTSxZQUFVLENBQUM7QUFBQSxXQUFNTixFQUFFLENBQUNPLEtBQUgsQ0FBU0MsT0FBVCxHQUFtQixDQUF6QjtBQUFBLEdBQUQsRUFBNkIsQ0FBN0IsQ0FBVjtBQUNELEM7Ozs7Ozs7Ozs7OztBQ0xEO0FBQUE7QUFBQTtBQUFBOzs7QUFJQTtBQUVPLFNBQVNDLFdBQVQsR0FBdUI7QUFDNUIsTUFBTUMsS0FBSyxHQUFHLENBQ1oxQixVQUFVLEVBREUsRUFFWjJCLGNBQWMsRUFGRixFQUdaQyxhQUFhLEVBSEQsQ0FBZDtBQUtBL0MsU0FBTyxDQUFDZ0QsR0FBUixDQUFZSCxLQUFaLEVBQ0czQyxJQURILENBQ1EsVUFBQStDLEtBQUs7QUFBQSxXQUFJQSxLQUFLLENBQUNDLE1BQU4sQ0FBYSxVQUFDQyxNQUFELEVBQVNDLElBQVQ7QUFBQSxhQUFrQkMsTUFBTSxDQUFDQyxNQUFQLENBQWNILE1BQWQsRUFBc0JDLElBQXRCLENBQWxCO0FBQUEsS0FBYixFQUE0RCxFQUE1RCxDQUFKO0FBQUEsR0FEYixFQUVHbEQsSUFGSCxDQUVRLFVBQUFxRCxNQUFNO0FBQUEsV0FBSUMsT0FBTyxDQUFDQyxVQUFSLENBQW1CRixNQUFuQixDQUFKO0FBQUEsR0FGZCxXQUdTLFVBQUFqRCxDQUFDO0FBQUEsV0FBSUMsTUFBTSxDQUFDQyxRQUFQLGtCQUEwQkYsQ0FBMUIsRUFBSjtBQUFBLEdBSFY7QUFJRDs7QUFFRCxTQUFTYSxVQUFULEdBQXNCO0FBQ3BCLFNBQU83QixpREFBUSxDQUFDNkIsVUFBVCxHQUNKakIsSUFESSxDQUNDLGdCQUE2QjtBQUFBLFFBQWpCd0QsVUFBaUIsUUFBMUJ0QyxPQUEwQjtBQUFFLFdBQU87QUFBRXNDLGdCQUFVLEVBQVZBO0FBQUYsS0FBUDtBQUF3QixHQUR4RCxDQUFQO0FBRUQ7O0FBRUQsU0FBU1osY0FBVCxHQUEwQjtBQUN4QixTQUFPeEQsaURBQVEsQ0FBQ3dELGNBQVQsR0FDSjVDLElBREksQ0FDQyxpQkFBdUI7QUFBQSxRQUFkeUQsT0FBYyxTQUFwQkMsSUFBb0I7QUFBRSxXQUFPO0FBQUVELGFBQU8sRUFBUEE7QUFBRixLQUFQO0FBQXFCLEdBRC9DLENBQVA7QUFFRDs7QUFFRCxTQUFTWixhQUFULEdBQXlCO0FBQ3ZCLFNBQU96RCxpREFBUSxDQUFDeUQsYUFBVCxHQUNKN0MsSUFESSxDQUNDLGlCQUF3RTtBQUFBLFFBQXJFWixRQUFxRSxTQUFyRUEsUUFBcUU7QUFBQSxRQUEzRHVFLFNBQTJELFNBQTNEQSxTQUEyRDtBQUFBLFFBQWhEQyxTQUFnRCxTQUFoREEsU0FBZ0Q7QUFBQSxRQUFyQ0MsU0FBcUMsU0FBckNBLFNBQXFDO0FBQUEsUUFBMUJDLFFBQTBCLFNBQTFCQSxRQUEwQjtBQUFBLFFBQWhCQyxTQUFnQixTQUFoQkEsU0FBZ0I7QUFDNUUsV0FBTztBQUFFM0UsY0FBUSxFQUFSQSxRQUFGO0FBQVl1RSxlQUFTLEVBQVRBLFNBQVo7QUFBdUJDLGVBQVMsRUFBVEEsU0FBdkI7QUFBa0NDLGVBQVMsRUFBVEEsU0FBbEM7QUFBNkNDLGNBQVEsRUFBUkEsUUFBN0M7QUFBdURDLGVBQVMsRUFBVEE7QUFBdkQsS0FBUDtBQUNELEdBSEksQ0FBUDtBQUlELEM7Ozs7Ozs7Ozs7OztBQ2pDRDtBQUFBO0FBQUE7QUFBQTs7O0FBSUE7QUFDQTtBQUVlO0FBQ2I5RCxPQUFLLEVBQUxBLEtBRGE7QUFFYmdCLFlBQVUsRUFBVkEsVUFGYTtBQUdiNUIsaUJBQWUsRUFBZkEsZUFIYTtBQUlidUQsZ0JBQWMsRUFBZEEsY0FKYTtBQUtiQyxlQUFhLEVBQWJBLGFBTGE7QUFNYm1CLFVBQVEsRUFBUkE7QUFOYSxDQUFmO0FBU0E7Ozs7QUFHQSxTQUFTL0QsS0FBVCxHQUFpQjtBQUNmLFNBQU9nRSx3REFBUyxDQUFDO0FBQUEsV0FBTUMsbURBQVcsQ0FBQ2pFLEtBQVosRUFBTjtBQUFBLEdBQUQsQ0FBaEI7QUFDRDtBQUVEOzs7OztBQUdBLFNBQVNnQixVQUFULEdBQXNCO0FBQ3BCLFNBQU9nRCx3REFBUyxDQUFDO0FBQUEsV0FBTUMsbURBQVcsQ0FBQ2pELFVBQVosRUFBTjtBQUFBLEdBQUQsQ0FBaEI7QUFDRDtBQUVEOzs7OztBQUdBLFNBQVM1QixlQUFULEdBQTJCO0FBQ3pCLFNBQU82RSxtREFBVyxDQUFDN0UsZUFBWixFQUFQO0FBQ0Q7QUFFRDs7Ozs7QUFHQSxTQUFTdUQsY0FBVCxHQUEwQjtBQUN4QixTQUFPcUIsd0RBQVMsQ0FBQztBQUFBLFdBQU1DLG1EQUFXLENBQUN0QixjQUFaLEVBQU47QUFBQSxHQUFELENBQWhCO0FBQ0Q7QUFFRDs7Ozs7QUFHQSxTQUFTQyxhQUFULEdBQXlCO0FBQ3ZCLFNBQU9vQix3REFBUyxDQUFDO0FBQUEsV0FBTUMsbURBQVcsQ0FBQ3JCLGFBQVosRUFBTjtBQUFBLEdBQUQsQ0FBaEI7QUFDRDs7QUFFRCxTQUFTbUIsUUFBVCxHQUFvQjtBQUNsQkUscURBQVcsQ0FBQ0YsUUFBWjtBQUNELEM7Ozs7Ozs7Ozs7OztBQ3JERDtBQUFBOzs7QUFJZTtBQUNiRyxjQUFZLEVBQUUsY0FERDtBQUViQyxNQUFJLEVBQUUsTUFGTztBQUdiQyxPQUFLLEVBQUUsVUFITTtBQUliQyxVQUFRLEVBQUU7QUFKRyxDQUFmLEU7Ozs7Ozs7Ozs7OztBQ0pBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7O0FBTUE7QUFDQTtBQUNBO0FBRUEsSUFBTUMsY0FBYyxHQUFHLDZCQUF2QjtJQUdFSixZLEdBSUVLLHNELENBSkZMLFk7SUFDQUMsSSxHQUdFSSxzRCxDQUhGSixJO0lBQ0FDLEssR0FFRUcsc0QsQ0FGRkgsSztJQUNBQyxRLEdBQ0VFLHNELENBREZGLFE7QUFHYTtBQUNickUsT0FBSyxFQUFMQSxLQURhO0FBRWJnQixZQUFVLEVBQVZBLFVBRmE7QUFHYjVCLGlCQUFlLEVBQWZBLDhEQUhhO0FBSWJ1RCxnQkFBYyxFQUFkQSxjQUphO0FBS2JDLGVBQWEsRUFBYkEsYUFMYTtBQU1ibUIsVUFBUSxFQUFSQTtBQU5hLENBQWY7O0FBU0EsU0FBUy9ELEtBQVQsR0FBaUI7QUFDZkksUUFBTSxDQUFDUSxHQUFQLHVCQUEwQjBELGNBQTFCO0FBQ0EsU0FBT0UsNkRBQWMsQ0FBQ0YsY0FBRCxDQUFyQjtBQUNEOztBQUVELFNBQVN0RCxVQUFULEdBQXNCO0FBQ3BCLE1BQU1DLE9BQU8sR0FBR3dELEtBQUssQ0FBQ0MsV0FBTixDQUFrQjFELFVBQWxCLEdBQStCQyxPQUEvQztBQUNBLFNBQU87QUFBRUEsV0FBTyxFQUFQQTtBQUFGLEdBQVA7QUFDRDs7QUFFRCxTQUFTOEMsUUFBVCxHQUFvQjtBQUNsQlUsT0FBSyxDQUFDQyxXQUFOLENBQWtCQyxxQkFBbEIsR0FBMENDLElBQTFDO0FBQ0Q7O0FBRUQsU0FBU2pDLGNBQVQsR0FBMEI7QUFDeEIsTUFBTWtDLElBQUksR0FBR0MsT0FBTyxDQUFDdEIsT0FBUixDQUFnQnVCLHVCQUFoQixFQUFiO0FBQ0EsTUFBTXRCLElBQUksR0FBRyxDQUFDUyxZQUFELEVBQWVDLElBQWYsRUFBcUJFLFFBQXJCLEVBQStCRCxLQUEvQixFQUFzQ1MsSUFBdEMsQ0FBYjtBQUNBLFNBQU87QUFBRXBCLFFBQUksRUFBSkE7QUFBRixHQUFQO0FBQ0Q7O0FBRUQsU0FBU2IsYUFBVCxHQUF5QjtBQUN2QixNQUFNYyxTQUFTLEdBQUdvQixPQUFPLENBQUNFLFdBQVIsQ0FBb0JDLFlBQXBCLEVBQWxCO0FBQ0EsTUFBTXRCLFNBQVMsR0FBR0QsU0FBUyxDQUFDd0IsS0FBVixDQUFnQixHQUFoQixFQUFxQixDQUFyQixDQUFsQjtBQUNBLE1BQU10QixTQUFTLEdBQUdrQixPQUFPLENBQUNFLFdBQVIsQ0FBb0JHLFlBQXBCLEVBQWxCO0FBQ0EsTUFBTXRCLFFBQVEsR0FBR2lCLE9BQU8sQ0FBQ0UsV0FBUixDQUFvQkksV0FBcEIsRUFBakI7QUFDQSxTQUFPO0FBQ0xqRyxZQUFRLEVBQUUsT0FETDtBQUVMdUUsYUFBUyxFQUFUQSxTQUZLO0FBR0xDLGFBQVMsRUFBVEEsU0FISztBQUlMQyxhQUFTLEVBQVRBLFNBSks7QUFLTEMsWUFBUSxFQUFSQTtBQUxLLEdBQVA7QUFPRCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUREOzs7OztBQU1BLElBQU13Qix3QkFBd0IsR0FBRywrQ0FBakM7QUFDQSxJQUFNQyxlQUFlLEdBQUcsU0FBeEI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0FBY08sU0FBU2xHLGVBQVQsR0FBMkI7QUFDaEMsU0FBT21HLG9CQUFvQixNQUFNQyxrQkFBa0IsRUFBbkQ7QUFDRDs7QUFFRCxTQUFTRCxvQkFBVCxHQUFnQztBQUM5QixNQUFNRSxhQUFhLEdBQUdoQixLQUFLLENBQUNDLFdBQU4sQ0FBa0JDLHFCQUFsQixHQUEwQ2Usc0JBQTFDLEVBQXRCOztBQUNBLE1BQUksQ0FBQ0MsMEJBQTBCLENBQUNGLGFBQUQsQ0FBL0IsRUFBZ0Q7QUFDOUMsV0FBTyxJQUFQO0FBQ0Q7O0FBQ0QsTUFBSUEsYUFBYSxDQUFDRyxVQUFkLENBQXlCQyxTQUF6QixLQUF1Q1Isd0JBQTNDLEVBQXFFO0FBQ25FLFdBQU8sSUFBUDtBQUNEOztBQUNELE1BQU1qQyxNQUFNLEdBQUcwQyxTQUFTLENBQUNMLGFBQWEsQ0FBQ0csVUFBZixDQUF4Qjs7QUFDQSxNQUFJLENBQUN4QyxNQUFMLEVBQWE7QUFDWCxXQUFPLElBQVA7QUFDRDtBQUNEOzs7Ozs7Ozs7QUFPQSxTQUFPMkMsYUFBYSxDQUFDM0MsTUFBRCxFQUFTNEMsY0FBVCxDQUFwQjtBQUNEOztBQUVELFNBQVNSLGtCQUFULEdBQThCO0FBQzVCLE1BQU10RyxZQUFZLEdBQUcsRUFBckI7QUFDQSxNQUFNK0csWUFBWSxHQUFHLENBQUNDLFFBQVEsQ0FBQ0MsTUFBVCxJQUFtQixFQUFwQixFQUF3QkMsT0FBeEIsQ0FBZ0MsS0FBaEMsRUFBdUMsRUFBdkMsRUFBMkNsQixLQUEzQyxDQUFpRCxHQUFqRCxDQUFyQjtBQUY0QjtBQUFBO0FBQUE7O0FBQUE7QUFHNUIseUJBQWtCZSxZQUFsQiw4SEFBZ0M7QUFBQSxVQUF2QkksS0FBdUI7O0FBQUEseUJBQ1JBLEtBQUssQ0FBQ25CLEtBQU4sQ0FBWSxHQUFaLENBRFE7QUFBQTtBQUFBLFVBQ3ZCb0IsSUFEdUI7QUFBQSxVQUNqQkMsS0FEaUI7O0FBRTlCckgsa0JBQVksQ0FBQ29ILElBQUQsQ0FBWixHQUFxQkUsa0JBQWtCLENBQUNELEtBQUQsQ0FBdkM7QUFDRDtBQU4yQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOztBQU81QixTQUFPckQsTUFBTSxDQUFDdUQsSUFBUCxDQUFZdkgsWUFBWixFQUEwQndILE1BQTFCLEdBQW1DLENBQW5DLEdBQXVDeEgsWUFBdkMsR0FBc0QsSUFBN0Q7QUFDRDs7QUFFRCxTQUFTeUcsMEJBQVQsQ0FBb0NGLGFBQXBDLEVBQW1EO0FBQ2pELFNBQU9BLGFBQWEsSUFDbEJBLGFBQWEsQ0FBQ0csVUFEVCxJQUVMSCxhQUFhLENBQUNHLFVBQWQsQ0FBeUJDLFNBRnBCLElBR0xKLGFBQWEsQ0FBQ0csVUFBZCxDQUF5QmUsSUFIcEIsSUFJTGxCLGFBQWEsQ0FBQ0csVUFBZCxDQUF5QmUsSUFBekIsQ0FBOEJELE1BSmhDO0FBS0Q7O0FBRUQsU0FBU1osU0FBVCxDQUFtQkYsVUFBbkIsRUFBK0I7QUFDN0IsTUFBTXhDLE1BQU0sR0FBR3dELHNCQUFzQixDQUFDaEIsVUFBVSxDQUFDZSxJQUFaLEVBQWtCckIsZUFBbEIsQ0FBckM7O0FBQ0EsTUFBSSxDQUFDdUIsY0FBYyxDQUFDekQsTUFBRCxDQUFuQixFQUE2QjtBQUMzQixXQUFPLElBQVA7QUFDRDs7QUFDRCxTQUFPQSxNQUFNLENBQUNtRCxLQUFQLENBQWEsQ0FBYixDQUFQO0FBQ0Q7O0FBRUQsU0FBU00sY0FBVCxDQUF3QnpELE1BQXhCLEVBQWdDO0FBQzlCLFNBQU9BLE1BQU0sSUFBSUEsTUFBTSxDQUFDNUQsR0FBakIsSUFBd0I0RCxNQUFNLENBQUNtRCxLQUEvQixJQUF3Q25ELE1BQU0sQ0FBQ21ELEtBQVAsQ0FBYUcsTUFBYixLQUF3QixDQUF2RSxDQUQ4QixDQUM0QztBQUMzRTtBQUVEOzs7Ozs7Ozs7O0FBUUEsU0FBU0Usc0JBQVQsQ0FBZ0NFLGNBQWhDLEVBQWdEdEgsR0FBaEQsRUFBcUQ7QUFDbkQsT0FBSyxJQUFJdUgsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsY0FBYyxDQUFDSixNQUFuQyxFQUEyQ0ssQ0FBQyxFQUE1QyxFQUFnRDtBQUM5QyxRQUFJRCxjQUFjLENBQUNDLENBQUQsQ0FBZCxDQUFrQnZILEdBQWxCLEtBQTBCQSxHQUE5QixFQUFtQztBQUNqQyxhQUFPc0gsY0FBYyxDQUFDQyxDQUFELENBQXJCO0FBQ0Q7QUFDRjs7QUFDRCxTQUFPLElBQVA7QUFDRDs7QUFFRCxTQUFTaEIsYUFBVCxDQUF1QlEsS0FBdkIsRUFBOEJTLE9BQTlCLEVBQXVDO0FBQ3JDLE1BQUk7QUFDRixXQUFPQyxJQUFJLENBQUNDLEtBQUwsQ0FBV1gsS0FBWCxFQUFrQlMsT0FBbEIsQ0FBUDtBQUNELEdBRkQsQ0FFRSxPQUFPRyxFQUFQLEVBQVc7QUFDWCxXQUFPLElBQVA7QUFDRDtBQUNGOztBQUVELFNBQVNuQixjQUFULENBQXdCeEcsR0FBeEIsRUFBNkIrRyxLQUE3QixFQUFvQztBQUNsQyxTQUFPLE9BQU9BLEtBQVAsS0FBaUIsUUFBakIsR0FBNEJDLGtCQUFrQixDQUFDRCxLQUFELENBQTlDLEdBQXdEQSxLQUEvRDtBQUNELEM7Ozs7Ozs7Ozs7OztBQzFHRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7Ozs7O0FBS0E7Ozs7QUFJTyxTQUFTL0IsY0FBVCxDQUF3QjRDLEtBQXhCLEVBQStCO0FBQ3BDLE1BQU1DLFFBQVEsR0FBR3BGLFFBQVEsQ0FBQ0MsYUFBVCxDQUF1QixRQUF2QixDQUFqQjtBQUNBbUYsVUFBUSxDQUFDQyxHQUFULEdBQWVGLEtBQWY7QUFDQUMsVUFBUSxDQUFDNUQsSUFBVCxHQUFnQixpQkFBaEI7QUFDQTRELFVBQVEsQ0FBQ0UsWUFBVCxDQUFzQixhQUF0QixFQUFxQyxXQUFyQztBQUNBdEYsVUFBUSxDQUFDdUYsSUFBVCxDQUFjbkYsV0FBZCxDQUEwQmdGLFFBQTFCO0FBQ0EsU0FBT0ksc0JBQXNCLENBQUNKLFFBQUQsQ0FBN0I7QUFDRDtBQUVNLFNBQVNLLFVBQVQsQ0FBb0JDLElBQXBCLEVBQTBCO0FBQy9CLE1BQU1DLEdBQUcsR0FBR0MsV0FBVyxDQUFDRixJQUFJLENBQUNHLE9BQUwsRUFBRCxDQUF2QjtBQUNBLE1BQU1DLEtBQUssR0FBR0YsV0FBVyxDQUFDRixJQUFJLENBQUNLLFFBQUwsS0FBa0IsQ0FBbkIsQ0FBekI7QUFDQSxNQUFNQyxJQUFJLEdBQUdOLElBQUksQ0FBQ08sV0FBTCxFQUFiO0FBQ0EsTUFBTUMsS0FBSyxHQUFHTixXQUFXLENBQUNGLElBQUksQ0FBQ1MsUUFBTCxFQUFELENBQXpCO0FBQ0EsTUFBTUMsT0FBTyxHQUFHUixXQUFXLENBQUNGLElBQUksQ0FBQ1csVUFBTCxFQUFELENBQTNCO0FBQ0EsbUJBQVVWLEdBQVYsY0FBaUJHLEtBQWpCLGNBQTBCRSxJQUExQixjQUFrQ0UsS0FBbEMsY0FBMkNFLE9BQTNDO0FBQ0Q7QUFFTSxTQUFTckUsU0FBVCxDQUFtQnVFLEVBQW5CLEVBQXVCO0FBQzVCLFNBQU8xSSxPQUFPLENBQUNDLE9BQVIsR0FDSkMsSUFESSxDQUNDO0FBQUEsV0FBTXdJLEVBQUUsRUFBUjtBQUFBLEdBREQsQ0FBUDtBQUVEO0FBRU0sU0FBU0MsaUJBQVQsQ0FBMkJDLEdBQTNCLEVBQWdDO0FBQ3JDLFNBQU8sT0FBT0EsR0FBUCxLQUFlLFFBQWYsR0FBMEJBLEdBQUcsQ0FBQ3JDLE9BQUosQ0FBWSxRQUFaLEVBQXNCLFdBQXRCLENBQTFCLEdBQStEcUMsR0FBdEU7QUFDRDs7QUFFRCxTQUFTaEIsc0JBQVQsQ0FBZ0NpQixRQUFoQyxFQUEwQztBQUN4QyxTQUFPLElBQUk3SSxPQUFKLENBQVksVUFBQ0MsT0FBRCxFQUFVNkksTUFBVixFQUFxQjtBQUN0Q0QsWUFBUSxDQUFDNUcsZ0JBQVQsQ0FBMEIsTUFBMUIsRUFBa0M7QUFBQSxhQUFNaEMsT0FBTyxDQUFDNEksUUFBRCxDQUFiO0FBQUEsS0FBbEM7QUFDQUEsWUFBUSxDQUFDNUcsZ0JBQVQsQ0FBMEIsT0FBMUIsRUFBbUMsVUFBQThHLEtBQUs7QUFBQSxhQUFJRCxNQUFNLENBQUNDLEtBQUQsRUFBUUYsUUFBUixDQUFWO0FBQUEsS0FBeEM7QUFDRCxHQUhNLENBQVA7QUFJRDs7QUFFRCxTQUFTYixXQUFULENBQXFCZ0IsR0FBckIsRUFBMEI7QUFDeEIsU0FBTyxXQUFJQSxHQUFKLEVBQVVDLEtBQVYsQ0FBZ0IsQ0FBQyxDQUFqQixDQUFQO0FBQ0QsQyIsImZpbGUiOiJwa2cvYm9vdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0ge307XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL2Jvb3QvaW5kZXguanNcIik7XG4iLCIvKipcbiAqIEBhdXRob3IgYWw4OFxuICogQG92ZXJ2aWV3INCc0L7QtNGD0LvRjCDQtNC70Y8g0YDQsNCx0L7RgtGLINGBINC/0LDRgNCw0LzQtdGC0YDQsNC80Lgg0LfQsNC/0YPRgdC60LAg0L/RgNC40LvQvtC20LXQvdC40Y9cbiAqL1xuXG5pbXBvcnQgcGxhdGZvcm0gZnJvbSAnLi4vcGxhdGZvcm0nO1xuXG5leHBvcnQgZGVmYXVsdCB7XG5cbiAgLyoqXG4gICAqINCh0L7RhdGA0LDQvdGP0LXQvCDQv9Cw0YDQsNC80LXRgtGA0Ysg0LfQsNC/0YPRgdC60LAg0LIg0LPQu9C+0LHQsNC70YzQvdGD0Y4g0L/QtdGA0LXQvNC10L3QvdGD0Y4gYGxhdW5jaFBhcmFtc2BcbiAgICovXG4gIGluaXQoKSB7XG4gICAgd2luZG93LmxhdW5jaFBhcmFtcyA9IHBsYXRmb3JtLmdldExhdW5jaFBhcmFtcygpO1xuICB9LFxuXG4gIGdldCBpc0VtcHR5KCkge1xuICAgIHJldHVybiBCb29sZWFuKGxhdW5jaFBhcmFtcyk7XG4gIH0sXG5cbiAgZ2V0KGtleSkge1xuICAgIHJldHVybiB0aGlzLl9pc0xhdW5jaFBhcmFtRXhpc3Qoa2V5KSA/IHdpbmRvdy5sYXVuY2hQYXJhbXNba2V5XSA6IGFwcENvbmZpZ1trZXldO1xuICB9LFxuXG4gIF9pc0xhdW5jaFBhcmFtRXhpc3Qoa2V5KSB7XG4gICAgcmV0dXJuIHdpbmRvdy5sYXVuY2hQYXJhbXMgJiYgd2luZG93LmxhdW5jaFBhcmFtc1trZXldICE9PSB1bmRlZmluZWQ7XG4gIH1cbn07XG4iLCIvKipcbiAqIEJvb3QgYXBwLlxuICovXG5cbi8qKlxuICog0J/QsNGA0LDQvNC10YLRgNGLINC/0YDQuNC70L7QttC10L3QuNGPLlxuICog0JXRgdC70Lgg0L/RgNC40LvQvtC20LXQvdC40LUg0LHRi9C70L4g0L7RgtC60YDRi9GC0L4g0YEg0L/QtdGA0LXQtNCw0YfQtdC5INC/0LDRgNCw0LzQtdGC0YDQvtCyINC00LvRjyDQvtGC0LvQsNC00LrQuCxcbiAqINGC0L4g0LjQtyDQvtCx0YrQtdC60YLQsCBSZXF1ZXN0ZWRBcHBDb250cm9sINCy0YvRgtCw0YHQutC40LLQsNC10Lwg0LDQtNGA0LXRgdCwINGB0YLQuNC70LXQuSwganMt0YHQutGA0LjQv9GC0LAg0Lgg0L7RgtC60YDRi9Cy0LDQtdC80L7QuSDQsiDQtNCw0LvRjNC90LXQudGI0LXQvCBXZWJWaWV3LlxuICog0JXRgdC70Lgg0LbQtSDQv9GA0LjQu9C+0LbQtdC90LjQtSDQsdGL0LvQviDQvtGC0LrRgNGL0YLQviDRgdGC0LDQvdC00LDRgNGC0L3QviAtINC40Lcg0Y/RgNC70YvQutCwINCyIFNtYXJ0SHViJ9C1LFxuICog0YLQviDQt9Cw0LPRgNGD0LbQsNGO0YLRgdGPINGA0LXRgdGD0YDRgdGLINC/0L4gcHJvZC3RgdGB0YvQu9C60LDQvC5cbiAqL1xuXG4vKiBnbG9iYWwgYXBwQ29uZmlnICovXG5cbmltcG9ydCBwbGF0Zm9ybSBmcm9tICcuLi9wbGF0Zm9ybSc7XG5pbXBvcnQgYXBwUGFyYW1zIGZyb20gJy4vYXBwLXBhcmFtcyc7XG5pbXBvcnQgKiBhcyBsb2dvIGZyb20gJy4vbG9nbyc7XG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICcuLi91dGlscyc7XG5pbXBvcnQgKiBhcyBzdGF0aXN0aWNzIGZyb20gJy4vc3RhdGlzdGljcyc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEJvb3RBcHAge1xuICBydW4oKSB7XG4gICAgUHJvbWlzZS5yZXNvbHZlKClcbiAgICAgIC50aGVuKCgpID0+IHBsYXRmb3JtLnNldHVwKCkpXG4gICAgICAudGhlbigoKSA9PiBhcHBQYXJhbXMuaW5pdCgpKVxuICAgICAgLnRoZW4oKCkgPT4gdGhpcy5fYm9vdCgpKVxuICAgICAgLmNhdGNoKGUgPT4gbG9nZ2VyLmxvZ0Vycm9yKGBFcnJvcjogJHtlfWApKTtcbiAgfVxuXG4gIF9ib290KCkge1xuICAgIFByb21pc2UucmVzb2x2ZSgpXG4gICAgICAudGhlbihzaG93RGV2aWNlSW5mbylcbiAgICAgIC50aGVuKHNob3dBcHBJbmZvKVxuICAgICAgLnRoZW4oKCkgPT4gbG9nby5zaG93KCkpXG4gICAgICAudGhlbihzZXR1cExvZ2dlcilcbiAgICAgIC50aGVuKGxvYWRKUylcbiAgICAgIC50aGVuKCgpID0+IHN0YXRpc3RpY3Muc2VuZEVudkluZm8oKSlcbiAgICAgIC5jYXRjaChlID0+IGxvZ2dlci5sb2dFcnJvcihgRXJyb3I6ICR7ZX1gKSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gc2hvd0RldmljZUluZm8oKSB7XG4gIGxvZ2dlci5sb2coYFNjcmVlbjogJHtzY3JlZW4ud2lkdGh9eCR7c2NyZWVuLmhlaWdodH1gKTtcbn1cblxuZnVuY3Rpb24gc2hvd0FwcEluZm8oKSB7XG4gIHJldHVybiBwbGF0Zm9ybS5nZXRBcHBJbmZvKClcbiAgICAudGhlbigoeyB2ZXJzaW9uIH0pID0+IGxvZ0FwcEluZm8odmVyc2lvbikpO1xufVxuXG5mdW5jdGlvbiBsb2dBcHBJbmZvKHZlcnNpb24pIHtcbiAgY29uc3QgYnVpbGREYXRlID0gdXRpbHMucHJldHR5RGF0ZShuZXcgRGF0ZShhcHBDb25maWcuYnVpbGREYXRlKSk7XG4gIGxvZ2dlci5sb2coYFZlcnNpb246ICR7dmVyc2lvbn0gKCR7YXBwQ29uZmlnLmJ1aWxkVHlwZX0pLCBidWlsZERhdGU6ICR7YnVpbGREYXRlfWApO1xuICBsb2dnZXIubG9nKGBMYXVuY2ggcGFyYW1zOiAke2FwcFBhcmFtcy5pc0VtcHR5ID8gJ3llcycgOiAnbm8nfWApO1xufVxuXG5mdW5jdGlvbiBzZXR1cExvZ2dlcigpIHtcbiAgaWYgKGFwcFBhcmFtcy5nZXQoJ3Nob3dMb2cnKSkge1xuICAgIGxvZ2dlci5zaG93KCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gbG9hZEpTKCkge1xuICBjb25zdCBqc0xpbmsgPSBnZXRKU0xpbmsoKTtcbiAgbG9nZ2VyLmxvZyhgTG9hZGluZyBqczogJHtqc0xpbmt9YCk7XG4gIC8vIHRvZG8g0JjRgdC/0YDQsNCy0LjRgtGMINGH0LXRgNC90YvQuSDRjdC60YDQsNC9INCyINGB0LvRg9GH0LDQtSwg0LXRgdC70Lgg0YHQutGA0LjQv9GCINC90LUg0LfQsNCz0YDRg9C30LjQu9GB0Y9cbiAgdGltaW5ncy5zdGFydCgnbG9hZGVyTG9hZCcpO1xuICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKClcbiAgICAudGhlbigoKSA9PiB1dGlscy5hcHBlbmRKU1NjcmlwdChqc0xpbmspKVxuICAgIC50aGVuKCgpID0+IHRpbWluZ3MuZmluaXNoKCdsb2FkZXJMb2FkJykpXG4gICAgLmNhdGNoKGUgPT4gbG9nZ2VyLmxvZ0Vycm9yKGBFcnJvcjogJHtlfWApKTtcbn1cblxuZnVuY3Rpb24gZ2V0SlNMaW5rKCkge1xuICBjb25zdCBqc1BhcmFtID0gYXBwUGFyYW1zLmdldCgnanMnKTtcbiAgcmV0dXJuIGFwcFBhcmFtcy5nZXQoJ2RlYnVnJykgPyB1dGlscy5jb252ZXJ0VG9EZWJ1Z1VybChqc1BhcmFtKSA6IGpzUGFyYW07XG59XG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW4iLCIvKipcbiAqIEBhdXRob3IgYWw4OFxuICogQG92ZXJ2aWV3INCS0YXQvtC00L3QsNGPINGC0L7Rh9C60LAg0YHQutGA0LjQv9GC0LAg0KLQki3Qv9GA0LjQu9C+0LbQtdC90LjRj1xuICovXG5cbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0IEJvb3RBcHAgZnJvbSAnLi9hcHAnO1xuXG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignRE9NQ29udGVudExvYWRlZCcsICgpID0+IG5ldyBCb290QXBwKCkucnVuKCkpO1xuXG50aW1pbmdzLmZpbmlzaCgnbG9jYWxSZXNvdXJjZXNMb2FkJyk7XG4iLCJleHBvcnQgZnVuY3Rpb24gc2hvdygpIHtcbiAgY29uc3QgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgZWwuaWQgPSAnbG9nbyc7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZWwpO1xuICBzZXRUaW1lb3V0KCgpID0+IGVsLnN0eWxlLm9wYWNpdHkgPSAxLCAwKTtcbn1cbiIsIi8qKlxuICog0JzQvtC00YPQu9GMINC00LvRjyDQv9C+0LTQs9C+0YLQvtCy0LrQuCDQuCDQvtGC0L/RgNCw0LLQutC4INGB0YLQsNGC0LjRgdGC0LjQutC4XG4gKi9cblxuaW1wb3J0IHBsYXRmb3JtIGZyb20gJy4uL3BsYXRmb3JtJztcblxuZXhwb3J0IGZ1bmN0aW9uIHNlbmRFbnZJbmZvKCkge1xuICBjb25zdCB0YXNrcyA9IFtcbiAgICBnZXRBcHBJbmZvKCksXG4gICAgZ2V0TmV0d29ya0luZm8oKSxcbiAgICBnZXREZXZpY2VJbmZvKCksXG4gIF07XG4gIFByb21pc2UuYWxsKHRhc2tzKVxuICAgIC50aGVuKGluZm9zID0+IGluZm9zLnJlZHVjZSgocmVzdWx0LCBpbmZvKSA9PiBPYmplY3QuYXNzaWduKHJlc3VsdCwgaW5mbyksIHt9KSlcbiAgICAudGhlbihwYXJhbXMgPT4gbWV0cmlrYS5zZW5kUGFyYW1zKHBhcmFtcykpXG4gICAgLmNhdGNoKGUgPT4gbG9nZ2VyLmxvZ0Vycm9yKGBFcnJvcjogJHtlfWApKTtcbn1cblxuZnVuY3Rpb24gZ2V0QXBwSW5mbygpIHtcbiAgcmV0dXJuIHBsYXRmb3JtLmdldEFwcEluZm8oKVxuICAgIC50aGVuKCh7IHZlcnNpb246IGFwcFZlcnNpb24gfSkgPT4geyByZXR1cm4geyBhcHBWZXJzaW9uIH07IH0pO1xufVxuXG5mdW5jdGlvbiBnZXROZXR3b3JrSW5mbygpIHtcbiAgcmV0dXJuIHBsYXRmb3JtLmdldE5ldHdvcmtJbmZvKClcbiAgICAudGhlbigoeyB0eXBlOiBuZXR3b3JrIH0pID0+IHsgcmV0dXJuIHsgbmV0d29yayB9OyB9KTtcbn1cblxuZnVuY3Rpb24gZ2V0RGV2aWNlSW5mbygpIHtcbiAgcmV0dXJuIHBsYXRmb3JtLmdldERldmljZUluZm8oKVxuICAgIC50aGVuKCh7IHBsYXRmb3JtLCBtb2RlbENvZGUsIG1vZGVsWWVhciwgbW9kZWxOYW1lLCBmaXJtd2FyZSwgb3NWZXJzaW9uIH0pID0+IHtcbiAgICAgIHJldHVybiB7IHBsYXRmb3JtLCBtb2RlbENvZGUsIG1vZGVsWWVhciwgbW9kZWxOYW1lLCBmaXJtd2FyZSwgb3NWZXJzaW9uIH07XG4gICAgfSk7XG59XG4iLCIvKipcbiAqINCe0LHRidCw0Y8g0L7QsdC10YDRgtC60LAg0L3QsNC0IEFQSSDQv9C70LDRgtGE0L7RgNC8XG4gKi9cblxuaW1wb3J0IHBsYXRmb3JtQXBpIGZyb20gJ3BsYXRmb3JtQXBpJztcbmltcG9ydCB7IHByb21pc2lmeSB9IGZyb20gJy4uL3V0aWxzJztcblxuZXhwb3J0IGRlZmF1bHQge1xuICBzZXR1cCxcbiAgZ2V0QXBwSW5mbyxcbiAgZ2V0TGF1bmNoUGFyYW1zLFxuICBnZXROZXR3b3JrSW5mbyxcbiAgZ2V0RGV2aWNlSW5mbyxcbiAgY2xvc2VBcHAsXG59O1xuXG4vKipcbiAqIEByZXR1cm5zIHtQcm9taXNlfVxuICovXG5mdW5jdGlvbiBzZXR1cCgpIHtcbiAgcmV0dXJuIHByb21pc2lmeSgoKSA9PiBwbGF0Zm9ybUFwaS5zZXR1cCgpKTtcbn1cblxuLyoqXG4gKiBAcmV0dXJucyB7UHJvbWlzZS48T2JqZWN0Pn1cbiAqL1xuZnVuY3Rpb24gZ2V0QXBwSW5mbygpIHtcbiAgcmV0dXJuIHByb21pc2lmeSgoKSA9PiBwbGF0Zm9ybUFwaS5nZXRBcHBJbmZvKCkpO1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtPYmplY3R9XG4gKi9cbmZ1bmN0aW9uIGdldExhdW5jaFBhcmFtcygpIHtcbiAgcmV0dXJuIHBsYXRmb3JtQXBpLmdldExhdW5jaFBhcmFtcygpO1xufVxuXG4vKipcbiAqIEByZXR1cm5zIHtQcm9taXNlLjxPYmplY3Q+fVxuICovXG5mdW5jdGlvbiBnZXROZXR3b3JrSW5mbygpIHtcbiAgcmV0dXJuIHByb21pc2lmeSgoKSA9PiBwbGF0Zm9ybUFwaS5nZXROZXR3b3JrSW5mbygpKTtcbn1cblxuLyoqXG4gKiBAcmV0dXJucyB7UHJvbWlzZS48T2JqZWN0Pn1cbiAqL1xuZnVuY3Rpb24gZ2V0RGV2aWNlSW5mbygpIHtcbiAgcmV0dXJuIHByb21pc2lmeSgoKSA9PiBwbGF0Zm9ybUFwaS5nZXREZXZpY2VJbmZvKCkpO1xufVxuXG5mdW5jdGlvbiBjbG9zZUFwcCgpIHtcbiAgcGxhdGZvcm1BcGkuY2xvc2VBcHAoKTtcbn1cbiIsIi8qKlxuICog0KLQuNC/0Ysg0L/QvtC00LrQu9GO0YfQtdC90LjRj1xuICovXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgRElTQ09OTkVDVEVEOiAnRElTQ09OTkVDVEVEJyxcbiAgV0lGSTogJ1dJRkknLFxuICBXSVJFRDogJ0VUSEVSTkVUJyxcbiAgQ0VMTFVMQVI6ICdDRUxMVUxBUicsXG59O1xuIiwiLyoqXG4gKiBUaXplbiBwbGF0Zm9ybSBpbXBsZW1lbnRhdGlvbi4gVXNlcyBnbG9iYWwgYHRpemVuYCBhbmQgYHdlYmFwaXNgLlxuICpcbiAqIFNlZTogaHR0cDovL2RldmVsb3Blci5zYW1zdW5nLmNvbS90di9kZXZlbG9wL2FwaS1yZWZlcmVuY2VzXG4gKi9cblxuaW1wb3J0IG5ldHdvcmtUeXBlcyBmcm9tICcuLi9uZXR3b3JrLXR5cGVzJztcbmltcG9ydCB7IGdldExhdW5jaFBhcmFtcyB9IGZyb20gJy4vbGF1bmNoLXBhcmFtcyc7XG5pbXBvcnQgeyBhcHBlbmRKU1NjcmlwdCB9IGZyb20gJy4uLy4uL3V0aWxzJztcblxuY29uc3QgQVBJX1NDUklQVF9VUkwgPSAnJFdFQkFQSVMvd2ViYXBpcy93ZWJhcGlzLmpzJztcblxuY29uc3Qge1xuICBESVNDT05ORUNURUQsXG4gIFdJRkksXG4gIFdJUkVELFxuICBDRUxMVUxBUlxufSA9IG5ldHdvcmtUeXBlcztcblxuZXhwb3J0IGRlZmF1bHQge1xuICBzZXR1cCxcbiAgZ2V0QXBwSW5mbyxcbiAgZ2V0TGF1bmNoUGFyYW1zLFxuICBnZXROZXR3b3JrSW5mbyxcbiAgZ2V0RGV2aWNlSW5mbyxcbiAgY2xvc2VBcHAsXG59O1xuXG5mdW5jdGlvbiBzZXR1cCgpIHtcbiAgbG9nZ2VyLmxvZyhgTG9hZGluZyBqczogJHtBUElfU0NSSVBUX1VSTH1gKTtcbiAgcmV0dXJuIGFwcGVuZEpTU2NyaXB0KEFQSV9TQ1JJUFRfVVJMKTtcbn1cblxuZnVuY3Rpb24gZ2V0QXBwSW5mbygpIHtcbiAgY29uc3QgdmVyc2lvbiA9IHRpemVuLmFwcGxpY2F0aW9uLmdldEFwcEluZm8oKS52ZXJzaW9uO1xuICByZXR1cm4geyB2ZXJzaW9uIH07XG59XG5cbmZ1bmN0aW9uIGNsb3NlQXBwKCkge1xuICB0aXplbi5hcHBsaWNhdGlvbi5nZXRDdXJyZW50QXBwbGljYXRpb24oKS5leGl0KCk7XG59XG5cbmZ1bmN0aW9uIGdldE5ldHdvcmtJbmZvKCkge1xuICBjb25zdCBjb2RlID0gd2ViYXBpcy5uZXR3b3JrLmdldEFjdGl2ZUNvbm5lY3Rpb25UeXBlKCk7XG4gIGNvbnN0IHR5cGUgPSBbRElTQ09OTkVDVEVELCBXSUZJLCBDRUxMVUxBUiwgV0lSRURdW2NvZGVdO1xuICByZXR1cm4geyB0eXBlIH07XG59XG5cbmZ1bmN0aW9uIGdldERldmljZUluZm8oKSB7XG4gIGNvbnN0IG1vZGVsQ29kZSA9IHdlYmFwaXMucHJvZHVjdGluZm8uZ2V0TW9kZWxDb2RlKCk7XG4gIGNvbnN0IG1vZGVsWWVhciA9IG1vZGVsQ29kZS5zcGxpdCgnXycpWzBdO1xuICBjb25zdCBtb2RlbE5hbWUgPSB3ZWJhcGlzLnByb2R1Y3RpbmZvLmdldFJlYWxNb2RlbCgpO1xuICBjb25zdCBmaXJtd2FyZSA9IHdlYmFwaXMucHJvZHVjdGluZm8uZ2V0RmlybXdhcmUoKTtcbiAgcmV0dXJuIHtcbiAgICBwbGF0Zm9ybTogJ1RpemVuJyxcbiAgICBtb2RlbENvZGUsXG4gICAgbW9kZWxZZWFyLFxuICAgIG1vZGVsTmFtZSxcbiAgICBmaXJtd2FyZSxcbiAgfTtcbn1cbiIsIi8qKlxuICogQGF1dGhvciBhbDg4XG4gKiBAb3ZlcnZpZXcg0KfQtdGA0LXQtyDRjdGC0L7RgiDQvNC+0LTRg9C70Ywg0LzQvtC20L3QviDQv9C+0LvRg9GH0LjRgtGMINC/0LDRgNCw0LzQtdGC0YDRiyDQt9Cw0L/Rg9GB0LrQsCDQv9GA0LjQu9C+0LbQtdC90LjRjyDQsiDRgNCw0YHQv9Cw0YDRiNC10L3QvdC+0Lwg0LLQuNC00LVcbiAqIEBzZWUgaHR0cHM6Ly9kZXZlbG9wZXIuc2Ftc3VuZy5jb20vdHYvZGV2ZWxvcC9leHRlbnNpb24tbGlicmFyaWVzL3NtYXJ0LXZpZXctc2RrL3NlbmRlci1hcHBzL2FuZHJvaWQtc2VuZGVyLWFwcC9lbmhhbmNlZC1mZWF0dXJlcyNzdGFydGFyZ3NcbiAqL1xuXG5jb25zdCBERUZBVUxUX0xBVU5DSF9PUEVSQVRJT04gPSAnaHR0cDovL3RpemVuLm9yZy9hcHBjb250cm9sL29wZXJhdGlvbi9kZWZhdWx0JztcbmNvbnN0IFBBUkFNU19EQVRBX0tFWSA9ICdQQVlMT0FEJztcblxuLyoqXG4gKiDQktGL0YLQsNGB0LrQuNCy0LDQtdGCINCw0LTRgNC10YHQsCDQt9Cw0LPRgNGD0LbQsNC10LzRi9GFINGA0LXRgdGD0YDRgdC+0LIg0LjQtyDQv9Cw0YDQsNC80LXRgtGA0L7QsiDQt9Cw0L/Rg9GB0LrQsC5cbiAqINCV0YHQu9C4INC/0YDQuNC70L7QttC10L3QuNC1INC30LDQv9GD0YnQtdC90L4g0YHRgtCw0L3QtNCw0YDRgtC90L4gLSDQuNC3IFNtYXJ0IEh1YiAtINGC0L4g0L/QsNGA0LDQvNC10YLRgNC+0LIg0LfQsNC/0YPRgdC60LAg0L3QtSDQsdGD0LTQtdGCLlxuICog0KLRg9GCINCy0LDQttC90L4g0L/RgNC+0LLQtdGA0Y/RgtGMINC+0L/QtdGA0LDRhtC40Y4gaHR0cDovL3RpemVuLm9yZy9hcHBjb250cm9sL29wZXJhdGlvbi9kZWZhdWx0LCDRgi7Qui4g0L/RgNC4INC30LDQv9GD0YHQutC1INC40Lcg0L/QsNC90LXQu9C4INC/0YDQtdCy0YzRjlxuICog0LIgUEFZTE9BRCDQstGB0LUt0YLQsNC60Lgg0LHRg9C00YPRgiDQtNCw0L3QvdGL0LUsINC90L4g0L7Qv9C10YDQsNGG0LjRjyDQsdGD0LTQtdGCINC00YDRg9Cz0LDRjy4g0J7QsdGA0LDQsdC+0YLQutCwIEFwcENvbnRyb2wg0LTQu9GPINC/0LDQvdC10LvQuCDQv9GA0LXQstGM0Y4g0YHQtNC10LvQsNC90LBcbiAqINCyIHNlcnZlciDRgdC60YDQuNC/0YLQsNGFINC00LvRjyDQstC+0LfQvNC+0LbQvdC+0YHRgtC4INC70LXQs9C60L4g0L7QsdC90L7QstC40YLRjC4g0JAg0YLRg9GCINC+0YHRgtCw0LLQu9GP0LXQvCDRgtC+0LvRjNC60L4g0L/QsNGA0YHQuNC90LMg0L/QsNGA0LDQvNC10YLRgNC+0LIg0LfQsNC/0YPRgdC60LAsXG4gKiDRh9GC0L7QsdGLINC30LDQs9GA0YPQt9C40YLRjCDQvdGD0LbQvdGL0LUg0YHQutGA0LjQv9GC0YsuXG4gKiDQmNC3LdC30LAg0YLQvtCz0L4g0YfRgtC+INC/0YDQuCDQtNC10LHQsNCz0LUg0L3QsCB0aXplbifQsNGFINC90LXRgiDQstC+0LfQvNC+0LbQvdC+0YHRgtC4INC/0YDQvtCx0YDQvtGB0LjRgtGMINC/0LDRgNCw0LzQtdGC0YDRiyDQt9Cw0L/Rg9GB0LrQsCwg0LTQtdC70LDQtdC8INGC0LDQutC20LUg0YTQvtC70LHRjdC6INC90LAg0YHRh9C40YLRi9Cy0LDQvdC40LVcbiAqINC/0LDRgNCw0LzQtdGC0YDQvtCyINC30LDQv9GD0YHQutCwINC40Lcg0YPRgNC70LAgKGh0dHBzOi8vc3QueWFuZGV4LXRlYW0ucnUvU01BUlRUVi0xMzcpXG4gKlxuICogQHNlZSBodHRwOi8vZGV2ZWxvcGVyLnNhbXN1bmcuY29tL3R2L2RldmVsb3AvYXBpLXJlZmVyZW5jZXMvdGl6ZW4td2ViLWRldmljZS1hcGktcmVmZXJlbmNlcy9hcHBsaWNhdGlvbi1hcGkjQXBwbGljYXRpb25Db250cm9sXG4gKlxuICogQHJldHVybnMgez9PYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRMYXVuY2hQYXJhbXMoKSB7XG4gIHJldHVybiBnZXRUaXplbkxhdW5jaFBhcmFtcygpIHx8IGdldFVybExhdW5jaFBhcmFtcygpO1xufVxuXG5mdW5jdGlvbiBnZXRUaXplbkxhdW5jaFBhcmFtcygpIHtcbiAgY29uc3QgcmVxQXBwQ29udHJvbCA9IHRpemVuLmFwcGxpY2F0aW9uLmdldEN1cnJlbnRBcHBsaWNhdGlvbigpLmdldFJlcXVlc3RlZEFwcENvbnRyb2woKTtcbiAgaWYgKCFpc1JlcXVlc3RlZEFwcENvbnRyb2xWYWxpZChyZXFBcHBDb250cm9sKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChyZXFBcHBDb250cm9sLmFwcENvbnRyb2wub3BlcmF0aW9uICE9PSBERUZBVUxUX0xBVU5DSF9PUEVSQVRJT04pIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBwYXJhbXMgPSBnZXRQYXJhbXMocmVxQXBwQ29udHJvbC5hcHBDb250cm9sKTtcbiAgaWYgKCFwYXJhbXMpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICAvKipcbiAgICog0JIg0YHQu9GD0YfQsNC1INC+0LHRi9GH0L3QvtCz0L4g0LfQsNC/0YPRgdC60LAg0L3Rg9C20L3QviDQtNC+0L/QvtC70L3QuNGC0LXQu9GM0L3QviDQt9Cw0LTQtdC60L7QtNC40YLRjCDRgdGC0YDQvtC60L7QstGL0LUg0L/QsNGA0LDQvNC10YLRgNGLLFxuICAgKiDRgtCw0Log0LrQsNC6INC+0L3QuCDQtNC+0LvQttC90Ysg0LHRi9C70Lgg0LHRi9GC0Ywg0LfQsNGN0L3QutC+0LbQtdC90Ysg0L3QsCDQutC70LjQtdC90YLQtSwg0LfQsNC/0YPRgdGC0LjQstGI0LXQvCDQv9GA0LjQu9C+0LbQtdC90LjQtSwg0LTQu9GPINGC0L7Qs9C+LFxuICAgKiDRh9GC0L7QsdGLINC90LUg0LLQvtC30L3QuNC60LDQu9CwINC+0YjQuNCx0LrQsCA1MDAg0L3QsCDRgtC10LvQtdCy0LjQt9C+0YDQtSDQuNC3LdC30LAg0YDRg9GB0YHQutC40YUg0YHQuNC80LLQvtC70L7QslxuICAgKlxuICAgKiBAc2VlIGh0dHBzOi8vZ2l0aHViLnlhbmRleC10ZWFtLnJ1L2Rlc2t0b3AvY2hyb21lLW5hbm8vYmxvYi9tYXN0ZXIvZXh0ZW5zaW9ucy90di9zcmMvYmFja2dyb3VuZC92ZW5kb3JzL3NhbXN1bmcvcnVubmVyLmpzI0w0N1xuICAgKi9cbiAgcmV0dXJuIHBhcnNlSnNvblNhZmUocGFyYW1zLCBkZWNvZGVJZlN0cmluZyk7XG59XG5cbmZ1bmN0aW9uIGdldFVybExhdW5jaFBhcmFtcygpIHtcbiAgY29uc3QgbGF1bmNoUGFyYW1zID0ge307XG4gIGNvbnN0IHNlYXJjaFBhcmFtcyA9IChsb2NhdGlvbi5zZWFyY2ggfHwgJycpLnJlcGxhY2UoL15cXD8vLCAnJykuc3BsaXQoJyYnKTtcbiAgZm9yIChsZXQgcGFyYW0gb2Ygc2VhcmNoUGFyYW1zKSB7XG4gICAgY29uc3QgW25hbWUsIHZhbHVlXSA9IHBhcmFtLnNwbGl0KCc9Jyk7XG4gICAgbGF1bmNoUGFyYW1zW25hbWVdID0gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LmtleXMobGF1bmNoUGFyYW1zKS5sZW5ndGggPiAwID8gbGF1bmNoUGFyYW1zIDogbnVsbDtcbn1cblxuZnVuY3Rpb24gaXNSZXF1ZXN0ZWRBcHBDb250cm9sVmFsaWQocmVxQXBwQ29udHJvbCkge1xuICByZXR1cm4gcmVxQXBwQ29udHJvbCAmJlxuICAgIHJlcUFwcENvbnRyb2wuYXBwQ29udHJvbCAmJlxuICAgIHJlcUFwcENvbnRyb2wuYXBwQ29udHJvbC5vcGVyYXRpb24gJiZcbiAgICByZXFBcHBDb250cm9sLmFwcENvbnRyb2wuZGF0YSAmJlxuICAgIHJlcUFwcENvbnRyb2wuYXBwQ29udHJvbC5kYXRhLmxlbmd0aDtcbn1cblxuZnVuY3Rpb24gZ2V0UGFyYW1zKGFwcENvbnRyb2wpIHtcbiAgY29uc3QgcGFyYW1zID0gZ2V0QXBwQ29udHJvbERhdGFCeUtleShhcHBDb250cm9sLmRhdGEsIFBBUkFNU19EQVRBX0tFWSk7XG4gIGlmICghYXJlUGFyYW1zVmFsaWQocGFyYW1zKSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiBwYXJhbXMudmFsdWVbMF07XG59XG5cbmZ1bmN0aW9uIGFyZVBhcmFtc1ZhbGlkKHBhcmFtcykge1xuICByZXR1cm4gcGFyYW1zICYmIHBhcmFtcy5rZXkgJiYgcGFyYW1zLnZhbHVlICYmIHBhcmFtcy52YWx1ZS5sZW5ndGggPT09IDE7IC8vINCS0YHQtSDQv9Cw0YDQsNC80LXRgtGA0Ysg0L/QtdGA0LXQtNCw0Y7RgtGB0Y8g0LIg0L7QtNC90L7QuSDRgdGC0YDQvtC60LVcbn1cblxuLyoqXG4gKiDQndC1INC80L7QttC10Lwg0LjRgdC/0L7Qu9GM0LfQvtCy0LDRgtGMIEFycmF5LnByb3RvdHlwZS5maW5kKCksINGC0LDQuiDQutCw0Log0L7QvSDQvdC1INC/0L7QtNC00LXRgNC20LjQstCw0LXRgtGB0Y8g0L3QsCDQotCSXG4gKiBAcGFyYW0ge0FycmF5fSBhcHBDb250cm9sRGF0YVxuICogQHBhcmFtIHtTdHJpbmd9IGtleVxuICogQHJldHVybnMge0FycmF5fG51bGx9XG4gKlxuICogQHNlZSBodHRwOi8vZGV2ZWxvcGVyLnNhbXN1bmcuY29tL3R2L2RldmVsb3AvYXBpLXJlZmVyZW5jZXMvdGl6ZW4td2ViLWRldmljZS1hcGktcmVmZXJlbmNlcy9hcHBsaWNhdGlvbi1hcGkjQXBwbGljYXRpb25Db250cm9sRGF0YVxuICovXG5mdW5jdGlvbiBnZXRBcHBDb250cm9sRGF0YUJ5S2V5KGFwcENvbnRyb2xEYXRhLCBrZXkpIHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcHBDb250cm9sRGF0YS5sZW5ndGg7IGkrKykge1xuICAgIGlmIChhcHBDb250cm9sRGF0YVtpXS5rZXkgPT09IGtleSkge1xuICAgICAgcmV0dXJuIGFwcENvbnRyb2xEYXRhW2ldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cblxuZnVuY3Rpb24gcGFyc2VKc29uU2FmZSh2YWx1ZSwgcmV2aXZlcikge1xuICB0cnkge1xuICAgIHJldHVybiBKU09OLnBhcnNlKHZhbHVlLCByZXZpdmVyKTtcbiAgfSBjYXRjaCAoZXgpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5mdW5jdGlvbiBkZWNvZGVJZlN0cmluZyhrZXksIHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnID8gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKSA6IHZhbHVlO1xufVxuIiwiLyoqXG4gKiBAYXV0aG9yIGFsODhcbiAqIEBvdmVydmlldyDQo9GC0LjQu9C40YLQsNGA0L3Ri9C1INGE0YPQvdC60YbQuNC4XG4gKi9cblxuLyoqXG4gKiBAcGFyYW0ge1N0cmluZ30ganNTcmNcbiAqIEByZXR1cm5zIHtQcm9taXNlLjxFbGVtZW50Pn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFwcGVuZEpTU2NyaXB0KGpzU3JjKSB7XG4gIGNvbnN0IGpzU2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gIGpzU2NyaXB0LnNyYyA9IGpzU3JjO1xuICBqc1NjcmlwdC50eXBlID0gJ3RleHQvamF2YXNjcmlwdCc7XG4gIGpzU2NyaXB0LnNldEF0dHJpYnV0ZSgnY3Jvc3NvcmlnaW4nLCAnYW5vbnltb3VzJyk7XG4gIGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoanNTY3JpcHQpO1xuICByZXR1cm4gd2FpdEZvclJlc291cmNlTG9hZGluZyhqc1NjcmlwdCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwcmV0dHlEYXRlKGRhdGUpIHtcbiAgY29uc3QgZGF5ID0gcGFkTGVmdFplcm8oZGF0ZS5nZXREYXRlKCkpO1xuICBjb25zdCBtb250aCA9IHBhZExlZnRaZXJvKGRhdGUuZ2V0TW9udGgoKSArIDEpO1xuICBjb25zdCB5ZWFyID0gZGF0ZS5nZXRGdWxsWWVhcigpO1xuICBjb25zdCBob3VycyA9IHBhZExlZnRaZXJvKGRhdGUuZ2V0SG91cnMoKSk7XG4gIGNvbnN0IG1pbnV0ZXMgPSBwYWRMZWZ0WmVybyhkYXRlLmdldE1pbnV0ZXMoKSk7XG4gIHJldHVybiBgJHtkYXl9LiR7bW9udGh9LiR7eWVhcn0gJHtob3Vyc306JHttaW51dGVzfWA7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwcm9taXNpZnkoZm4pIHtcbiAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpXG4gICAgLnRoZW4oKCkgPT4gZm4oKSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb252ZXJ0VG9EZWJ1Z1VybCh1cmwpIHtcbiAgcmV0dXJuIHR5cGVvZiB1cmwgPT09ICdzdHJpbmcnID8gdXJsLnJlcGxhY2UoL1xcLmpzJC9pLCAnLmRlYnVnLmpzJykgOiB1cmw7XG59XG5cbmZ1bmN0aW9uIHdhaXRGb3JSZXNvdXJjZUxvYWRpbmcocmVzb3VyY2UpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICByZXNvdXJjZS5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgKCkgPT4gcmVzb2x2ZShyZXNvdXJjZSkpO1xuICAgIHJlc291cmNlLmFkZEV2ZW50TGlzdGVuZXIoJ2Vycm9yJywgZXJyb3IgPT4gcmVqZWN0KGVycm9yLCByZXNvdXJjZSkpO1xuICB9KTtcbn1cblxuZnVuY3Rpb24gcGFkTGVmdFplcm8oc3RyKSB7XG4gIHJldHVybiBgMCR7c3RyfWAuc2xpY2UoLTIpO1xufVxuIl0sInNvdXJjZVJvb3QiOiIifQ==